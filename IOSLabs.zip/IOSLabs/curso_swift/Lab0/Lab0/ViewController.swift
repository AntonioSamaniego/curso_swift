//
//  ViewController.swift
//  Lab0
//
//  Created by CCDM11 on 10/7/19.
//  Copyright © 2019 Coppel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var colorGreen = false;
    //MARK - OUtlets
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    // MARK - Actions
    @IBAction func changeColor(_ sender: Any) {
        if colorGreen{
            view.backgroundColor = UIColor.green;
            colorGreen = false;
        }else{
            view.backgroundColor = UIColor.white;
            colorGreen = true;
        }
    }
    
}

