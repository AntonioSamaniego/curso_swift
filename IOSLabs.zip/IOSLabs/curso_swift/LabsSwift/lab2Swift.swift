var shopping = ["Milk","Eggs","Coffe"];
var costs = ["Milk":1,"Eggs":2,"Coffe":3]
func costOf(items:[String],costs[String:Int]) -> Int {
    var cost = 0 
    for item in items {
        if  let cm = costs[item]{
            cost += cm
        }
    }
    return cost
}

// invocar la funcion 
costOf(item:shopping,costs:costs)
var salida = costOf(item:shopping,costs:costs)
_ = costOf(item:shopping,costs:costs)

//  funcion con etiquetas

func costOf1(canasta items:[String],precios costs[String:Int]) -> Int {
    var cost = 0 
    for item in items {
        if  let cm = costs[item]{
            cost += cm
        }
    }
    return cost
}
// invocar con etiquetas 
costOf1(canasta: shopping, precios: costs)

// funcion que ignora etiquetas

func echoString(_ s:String, times:Int)-> String{
    var result = ""
    for _ in 1...times{result += s} 
    return result 
}
echoString("hi",times:3)
// argumentos opcionales
func costOf2(canasta items:[String],precios costs[String:Int] = cost) -> Int {
    var cost = 0 
    for item in items {
        if  let cm = costs[item]{
            cost += cm
        }
    }
    return cost
}
costOf1(canasta: shopping)
var costs2 = ["Milk":10,"Eggs":20,"Coffe":30]

//funcion que regresa una estructura

struct MinMax {
    var min:Int
    var max:Int
}
func minmax3(numbers:Int...) -> Int? {
    var minmax = MinMax()
}
// funcion inout  
func swapTowInts(_ a: inout Int,_ b: inout Int){
    let temporaryA = a
    a = b
    b = temporaryA
}
var someInt = 3
var anotherInt = 107

swapTowInts(&someInt, &anotherInt)
print("someInt is now \(someInt),")
