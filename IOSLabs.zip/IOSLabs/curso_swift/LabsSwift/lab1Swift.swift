// variables y constantes
"Hola "+"Mundo"
20 + 5
23.5 +1
//variables coninferencias
var currentLoginAttemps = 10;
//constantes coninferencias
let maximumNumbersOfLogins = 20;
var x = 0.0, y = 0.0, z = 0.0;
//separaddor numerico '_'
var 123_456;
// sin inferencia
var wellcomeMessage: String = "hola" ;
x = "X";// error
// se redefine la variable para evitar errores :v 
var x = "X";
// Converciones
var etiqueta = "Ancho: ";
var ancho = 32;
let etiquetaAncho +  ancho ;// error
let etiquetaAncho + String(ancho);
print(etiqueta);
// Contstantes
etiquetaAncho = "Swift";// error las constantes no se pueden modificar


let minValue = UInt8.min
