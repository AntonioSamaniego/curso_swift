//
//  ViewController.swift
//  Lab9TipCalculator
//
//  Created by CCDM11 on 10/9/19.
//  Copyright © 2019 Coppel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtTotal: UITextField!
    @IBOutlet weak var scPorsentaje: UISegmentedControl!
    @IBOutlet weak var lblPropina: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func calcularPropina(_ sender: Any) {
        let total:Double? = Double(txtTotal.text!)
        var iva = 0.0
        
        switch (scPorsentaje.selectedSegmentIndex) {
            case 0:  iva = 0.10
            case 1:  iva = 0.15
            case 2:  iva = 0.20
            default: iva = 0
        }
        let calculado: Double = total! + (total! * iva)
        lblPropina.text = String(calculado)
        
    }
    
}

