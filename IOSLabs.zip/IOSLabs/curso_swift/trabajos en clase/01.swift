func esBisiesto(_ a:Int) -> Bool {
    return a % 4 == 0 && (!(a % 100 == 0) || (a % 400 == 0))
}
func diasPorMes(_ m:Int,_ a:Int) -> Int{
     var diasporMes = [31,28,31,30,31,30,31,31,30,31,30,31]
    if esBisiesto(a){
        diasporMes = [31,29,31,30,31,30,31,31,30,31,30,31]
    }
    return diasporMes[m]
}
func calcularEntrega(dia d:Int,mes m:Int, anio a:Int, diasRenta nDias:Int) -> String {
    let diasDelMes = diasPorMes(m - 1,a)
    var diaEntrega = 0, mesEntrega = 0, anioEntrega = 0
    diaEntrega = d + nDias
    if  diaEntrega >  diasDelMes {
        diaEntrega = diaEntrega - diasDelMes
        mesEntrega += 1
    }
    mesEntrega += m
    if mesEntrega > 11 {
        mesEntrega = mesEntrega - m
        anioEntrega += 1
    }
    mesEntrega + 1
    anioEntrega += a
     let entrega = "\(diaEntrega)/\(mesEntrega)/\(anioEntrega)"
    return entrega
}

calcularEntrega(dia:12, mes:5, anio:2019, diasRenta:15)
calcularEntrega(dia:17, mes:5, anio:2019, diasRenta:15)
calcularEntrega(dia:18, mes:12, anio:2019, diasRenta:15)