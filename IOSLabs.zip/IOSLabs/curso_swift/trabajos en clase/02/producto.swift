class Producto {
    var id:Int
    var name:String
    var desc:String
    var price: Double
    
    init(id:String, name:String, desc:String, price:Double){
        self.id = id
        self.name = name
        self.desc = desc
        self.price = price
    }
    //propiedad calculada
    var toString:String{
        get return "\(self.id), \(self.name), \(self.desc), \(self.price),"
    }
}
