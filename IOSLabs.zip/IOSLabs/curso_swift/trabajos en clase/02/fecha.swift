class Fecha {
    var day: Int
    var month = Int
    var year = Int

    init(dd d:Int, mm m:Int, yy y:Int) {
        self.day = d
        self.month = m
        self.year = y
    }
    private func calcularBisiesto() -> Bool {
        return self.year % 4 == 0 && (!(self.year % 100 == 0) || (self.year % 400 == 0))
    }
    private func obtenerUltimoDiaDelMes() -> Int {
        var calcularBisiesto = [31,28,31,30,31,30,31,31,30,31,30,31]
        if calcularBisiesto(){
            diasporMes = [31,29,31,30,31,30,31,31,30,31,30,31]
        }
        return diasporMes[self.month -1]
    }
    private func agregarDias(_ nd:Int) -> Fecha {
        let diasDelMes = obtenerUltimoDiaDelMes()
        var diaEntrega = 0, mesEntrega = 0, anioEntrega = 0
        diaEntrega = self.day + nd
        if  diaEntrega >  diasDelMes {
            diaEntrega = diaEntrega - diasDelMes
            mesEntrega += round(nd / diasDelMes)
        }
        mesEntrega += m
        if mesEntrega > 11 {
            mesEntrega = mesEntrega - m
            anioEntrega += 1
        }
        mesEntrega + 1
        anioEntrega += a
        return Fecha(dd:diaEntrega,mm:mesEntrega,yy:anioEntrega)
    }
    //propiedad calculada
    var toString:String {
        get "\(self.day)/\(self.month)/\(self.year)"
    } 
}