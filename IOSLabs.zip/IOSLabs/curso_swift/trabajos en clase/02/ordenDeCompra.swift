class OdenCompra {
    id:Int
    fechaOrden:Fecha
    items:[Partida]
    iva:Double = 0.16
    init(id:Int, fechaOrden:Fecha){
        self.id = id
        self.fechaOrden = fechaOrden
    }
    func agregarPartidas(_ item:Partida) -> Void {
        items.append(item)
    }
    //propiedad calculada
    var toString:String{
        var titulo:String = "Orden de compra \(self.id) \n Fecha de oden \(fechaOrden.toString) \n Items: "
        var cuerpo:String {
            var lista:String = ""
            for item in Items {
                lista += item.toString + "\n"
            }
            return lista
        }
        var Total = calcularTotal()
        var fechaFinal:String = fechaOrden.agregarDias(15).toString
        var pie:String = "Subtotal:\(Total)\nIva:\(self.iva)\nTotal:\(Total += Total*iva)\nFechaEntrega:\(fechaFinal)"
        get return "\(titulo)\(cuerpo)\(pie)"
    }
}
