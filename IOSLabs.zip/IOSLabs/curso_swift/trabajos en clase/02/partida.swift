class Partida {
    var id:Int
    var product:Producto
    var aty:Int
    
    init(id:Int, product:Producto, aty:Int){
        self.id = id
        self.product = product
        self.aty = aty
    }
    //propiedad calculada
    var toString:String{
        get return "\(self.id), \(self.product.name), \(self.aty)"
    }
}
