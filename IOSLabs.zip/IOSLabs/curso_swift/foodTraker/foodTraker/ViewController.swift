//
//  ViewController.swift
//  foodTraker
//
//  Created by CCDM11 on 10/9/19.
//  Copyright © 2019 Coppel. All rights reserved.
//

import UIKit

class ViewController: UIViewController,
    UITextFieldDelegate,
    UIImagePickerControllerDelegate,
    UINavigationControllerDelegate {
    //MARK PROPERTIES
    
    @IBOutlet weak var lblMealName1: UILabel!
    @IBOutlet weak var txtMealName: UITextField!
    @IBOutlet weak var photoImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtMealName.delegate = self
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func setDefaultLblText(_ sender: Any) {
        lblMealName1.text = "Meal Name madafaka"
        txtMealName.text = ""
    }
    @IBAction func selectImageFromPhotoLibrary(_ sender: Any) {
        txtMealName.resignFirstResponder()
        let imagePikerController = UIImagePickerController()
        imagePikerController.sourceType = .photoLibrary
        imagePikerController.delegate = self
        present(imagePikerController,animated: true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        //hide key board
        textField.resignFirstResponder()
        return true
    }
    //MARK UITextFieldDelegate
    func textFieldDidEndEditing(_ textField: UITextField) {
        lblMealName1.text = txtMealName.text
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        photoImageView.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    
    
}

