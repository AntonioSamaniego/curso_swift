let calculation = Maths(a: 2, b: 3)
		calculation.add()
		calculation.displayResult()
        print(String(describing: calculation.result!))
