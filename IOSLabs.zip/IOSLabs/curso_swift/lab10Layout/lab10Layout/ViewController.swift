//
//  ViewController.swift
//  lab10Layout
//
//  Created by CCDM11 on 10/10/19.
//  Copyright © 2019 Coppel. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad();
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttonTraped(_ sender: UIButton) {
        if sender.title(for: .normal) == "x"{
            sender.setTitle("A very Long Title for this button", for: .normal);
        }else{
            sender.setTitle("x", for: .normal);
        }
    }
    
}

