#!/usr/bin/env swift
let numbers = (1 ... 100)
let result = numbers.reduce(0, +) // combine to return a single value
print(result) //5050
